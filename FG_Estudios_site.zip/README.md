# F & G Estudos

Site de aprendizado de inglês — veja palavras em português, traduções em inglês e pronúncia.

## 🚀 Publicar via GitHub Pages

1. Crie um repositório no GitHub (ex: fg-estudos).
2. Faça upload do arquivo `index.html` deste ZIP.
3. Vá em Settings → Pages → escolha a branch principal → Salvar.
4. Acesse seu site em `https://seuusuario.github.io/fg-estudos`.

## 🌐 Publicar via Netlify

1. Vá em https://app.netlify.com
2. Clique em **Add new site → Deploy manually**.
3. Arraste o arquivo `index.html`.
4. Seu site estará online em segundos!

## 🎨 Personalização

Abra `index.html` no VS Code e altere textos, cores ou adicione recursos.
